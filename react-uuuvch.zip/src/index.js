import React, { Component } from 'react';
import { render } from 'react-dom';
import LoginPage from './Login.js';
import './style.css';

class App extends Component {
  constructor() {
    super();
    this.state = {
      name: 'React'
    };
  }

  render() {
    return (
      <div>
        <LoginPage username='user' password='pass'>;
        </LoginPage>
      </div>
    );
  }
}

render(<App />, document.getElementById('root'));
