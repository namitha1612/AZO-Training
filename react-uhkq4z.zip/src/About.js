import React, { Component } from "react";

class Aboutus extends React.Component {
    render() {
        return (

            <div>
            <h2>About Us</h2>
                <h3>Autozone</h3>
                <p>AutoZone, Inc. is an American retailer of aftermarket automotive parts and accessories, the largest in the United States.<br/><br/>
                <strong> Founded:</strong> 1979.<br/><br/>
                <strong> Headquarters: </strong> Memphis, Tennessee.<br/><br/>
                 AutoZone has over <strong> 6,300 stores </strong> across the United States, Mexico, and Brazil.
                 </p>
                </div>
        );
        }
  
}
export default Aboutus;