import React from 'react';
import './style.css';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Aboutus from './About.js';
import Findstore from './Header/Findstore.js';
import PartDetails from './Partdetails/Partdetails.js';
import Login from './LoginSignup/Logincomponent.js';
import SignUp from './LoginSignup/Signupcomponent.js';
import Cart from './Cart/Cart.js';

function App() {
  return (<Router>
    <div className="App">
    <table id="nav-menu" cellpadding="10" cellspacing="1">
		   <tbody><tr>
        <td class="logo"><h1>Autozone</h1></td>
            <td>   
              <Link to={"/sign-in"}>Login</Link>
              </td>
              <td> 
              <Link to={"/sign-up"}>Sign up</Link>
              </td>
              <td>              
              <Link to={"/about-us"}>About Us</Link>             
              </td>
              <td>
              <Link to={"/part-details"}>Part Details</Link>              
              </td>
              <td>
              <Link to={"/cart"}>Cart</Link>              
              </td>

            </tr></tbody></table><br/><br/>
            
        <div className="auth-inner">
        <Switch>
      <Route exact path='/' component={Aboutus} />
       <Route path='/sign-in' component={Login} />
       <Route path="/sign-up" component={SignUp} />
       <Route path="/about-us" component={Aboutus} />
       <Route path="/part-details" component={PartDetails} />
       <Route path="/cart" component={Cart} />
       </Switch>

        </div>
        
    </div></Router>
  );
}
export default App;
