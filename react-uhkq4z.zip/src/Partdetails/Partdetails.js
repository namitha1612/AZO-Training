import React from 'react';
import ReactDOM from 'react-dom';



class Partdetails extends React.Component{
  render(){
    return(
      <table cellpadding='0'>
      <h2>Part Details</h2>
      <tr id="one">
      <td>
      <h3>Aircleaner</h3>
      <p>An air purifier or air cleaner is a device which removes contaminants from the air in a room to improve indoor air quality. </p>
      </td></tr>
      <tr id="two">
      <td>
      <h3>Air Duct1</h3>
      <p>Air Duct1 are conduits or passages used to deliver and remove air. Air ducts are one method of ensuring acceptable indoor air quality as well as thermal comfort.</p>
      </td></tr>
      <tr id="three">
      <td>
      <h3>Air Duct2</h3>
      <p>Air Duct2 are conduits or passages used to deliver and remove air.Air ducts are one method of ensuring acceptable indoor air quality as well as thermal comfort</p>
      </td></tr>
      <tr id="four">
      <td>
      <h3>Inlet</h3>
      <p>Inlet is an opening or structure through which a fluid is admitted to a space or machine as a consequence of a pressure differential between the outside and the inside. </p>
      </td></tr>
      <tr id="five">
      <td>
      <h3>Outlet</h3>
      <p>Outlet is a part of a system that allows air to enter a plumbing system to maintain proper air pressure to enable the removal of sewage from a dwelling. </p>
      </td></tr>
      <tr id="six">
      <td>
      <h3>Row</h3>
      <p>Row is a type of pipe used to convey gases from one location to another.</p>
      </td></tr>
      <tr id="seven">
      <td>
      <h3>Suction</h3>
      <p>Suction is the force that a partial vacuum exerts upon a gas to seperate dust from gas.</p>
      </td></tr>
      <tr id="eight">
      <td>
      <h3>Tube Air Cleaner</h3>
      <p>Tube Air cleaner is  device composed of fibrous or porous materials which removes solid particulates such as dust, pollen, mold, and bacteria from the air.Tube Air cleaner are used in applications where air quality is important, notably in building ventilation systems and in engines. </p>
      </td></tr>
      </table>

    );

  }
}
export default Partdetails;