import React, { Component } from "react";

export default class SignUp extends Component {
    render() {
        return (
            <form>
                <h2>Sign Up</h2>
                <div>
                    <label>First name</label>
                    <input type="text" placeholder="First name" />
                </div><br />

                <div>
                    <label>Last name</label>
                    <input type="text" placeholder="Last name" />
                </div><br />

                <div>
                    <label>Email address</label>
                    <input type="email" placeholder="Enter email" />
                </div><br />

                <div>
                    <label>Password</label>
                    <input type="password" placeholder="Enter password" />
                </div><br />

                <button type="submit">Sign Up</button>
              
            </form>
        );
    }
}


