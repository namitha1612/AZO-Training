import React, { Component } from "react";
import {render} from 'react-dom';



class Login extends React.Component {

   render(){
return(
            <div>

                <form>
                <h2>Login</h2>
                <div>
                    <label>Email address</label>
                    <input type="email" placeholder="Enter email" />
                </div><br />

                <div>
                    <label>Password</label>
                    <input type="password" placeholder="Enter password" />
                </div><br />

                <div>
                    <input type="checkbox" />
                        <label>Remember me</label>
                </div><br />
                <button type="submit">Submit</button>          
            </form>
            </div>


);
   }
  }

export default Login;